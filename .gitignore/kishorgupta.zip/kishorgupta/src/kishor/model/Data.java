/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kishor.model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;

/**
 *
 * @author Kishor
 */
public class Data {
    public static boolean guptafile =false;
    public static String filename ="";
     public static String history ="";
      public static String filesize ="";
    public static BufferedInputStream in;
    public static BufferedOutputStream out;
    static double kilobytes;
}
