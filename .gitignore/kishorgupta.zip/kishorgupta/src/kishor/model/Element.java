/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kishor.model;

/**
 *
 * @author Kishor
 */
public class Element{
    public int prefix;
    public int suffix;

    public Element(int prefix, int suffix){
        this.prefix = prefix;
        this.suffix = suffix;
    }
}
